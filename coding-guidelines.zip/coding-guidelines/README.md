# Coding Guidelines

The Citizens coding guidelines provide references for developing solutions in a consistent manner, largely, if not entirely based on well-established industry guideliens for the respective languages and platforms, while allowing for variations within Citizens, as deemed necessary and appropriate by members of engineering leadership. 

The guides provided in this repository are intentionally kept brief and aim at highlighting commonly occuring anti-patterns, deviations from well-established guidelines, or issues that occur frequently within Citizens.

When possible, guidelines will be automated via SonarQube, linters, formatters, and similar tooling. The configurations for those tools, if available, will be referenced within the appropriate coding guidelines document.

## Precedence of Guidelines

Guidelines come from the following sources and in the event of a conflict, should be prioritized as follows (ordered from highest to lowest priority).

1. Centralized automated tooling (e.g. SonarQube running on the Enterprise Pipeline)
2. Configuration for automation referenced by the coding guidelines document
3. The coding guidelines document
4. Any externally linked guidelines.

 ## Guidelines

 ### Languages
- [Java](language-java.md)
- [JavaScript](language-javascript.md)
- [TypeScript](language-typescript.md)
- [C#](language-csharp.md)
- [Dart](language-dart.md)
- [Go](language-go.md)
- [Swift](language-swift.md)

 ### Development Platforms / Runtimes
 - [Node](platform-node.md)


 ### Development Frameworks
 - [Angular](framework-angular.md)
 - [React](framework-react.md)
 - [React](framework-vue.md)
 - [Flutter](framework-flutter.md)


 ## Contributing

 In addition to the [General Contribution Guidelines](../CONTRIBUTING.md), additional requirements and support for creating guidelines is outlined in [CONTRIBUTION.md](CONTRIBUTION.md). Support for creating guidelines is provided for Visual Studio Code, but as long as the format is followed, you may use any tooling of your choice.


 ## Questions/Comments

 If you have a question or suggestion on a particular guideline, please contact the authors listed at the top of the respective guide.

