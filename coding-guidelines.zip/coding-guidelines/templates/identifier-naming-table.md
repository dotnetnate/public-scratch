### Identifier Naming Reference
<table style="width:100%;">
    <tr>
        <td style="width:30%">Identifier Type</td>
        <td style="width:10%">Casing</td>
        <td style="width:20%">Pluralization</td>
        <td style="width:10%">Prefix</td>
        <td style="width:10%">Suffix</td>
        <td style="width:20%">Example</td>
    </tr>
    <tr>
        <td>${1:identifier_type}</td>
        <td>${2|Camel,Pascal,Snake,Macro,Kebab,Train}</td>
        <td>${3|Singular,Plural}</td>
        <td>${4:prefix}</td>
        <td>${5:suffix}</td>
        <td>${6:example}</td>
    </tr>
</table>
        