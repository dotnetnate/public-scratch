**${1:guideline}**
     
${2:rationale_and_usage}