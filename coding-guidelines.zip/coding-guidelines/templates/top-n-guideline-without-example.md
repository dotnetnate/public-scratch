${1:guideline_number}. ${2|do:xxxx,do_not:zzzz}
    * ${3:detail}