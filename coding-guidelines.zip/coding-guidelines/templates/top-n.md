<style>
    * {
        font-family:FiraSans,Arial,"Helvetica Neue",Helvetica,sans-serif
    }
    tr:first-child td {
        background-color: #008555;
        text-align:center;
    }
</style>
# ${1:language} Coding Standards

**Authors / Points of Contact**

* ${2:author}

## Purpose and Usage
The pupose of these guidelines is to provide a summary of elements we currently view as most important when developing software using ${1:language}. These guidelines are based on established guidelines within the ${1:language} community. Guidelines are routinely prioritized based on:

* Deviations from published industry standards.
* Common issues arising within the general ${1:language} community.
* Common issues found within Citizens when developing on ${1:language}.

These guidelines should not be considered exhaustive - please refer to the linked external resources for additional guidelines. Additionally, when possible, automation tools such as linters, SonarQube, etc. will be utilized to augment standards. 

In the event of a conflict, the following priority should be used to resolve conflicts (from highest to lowest):

* Enterprise or project-level automation
* This guide
* The linked external references


## Attributions and References

[External Link Here](https://about:blank) - This guide...

[External Link Here](https://about:blank) - This guide...

[External Link Here](https://about:blank) - This guide...

[External Link Here](https://about:blank) - This guide...


## Contributions

Refer to the [Contribution Guide](contributing.md) for contributions to this and other coding guidelines.


## Top ${3:guideline_count} Guidelines
