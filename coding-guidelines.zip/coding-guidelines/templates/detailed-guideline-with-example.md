**${1:guideline}**
     
${2:rationale_and_usage}


:white_check_mark: Do this
```${3:languagecode}
${4:example}
```

:x: Not this
```${3:languagecode}
${4:counter_example}
```